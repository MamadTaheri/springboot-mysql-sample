package com.mamadtaheri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMysqlSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMysqlSampleApplication.class, args);
	}

}
